window.CKEDITOR_BASEPATH = '/profiles/cms/libraries/ckeditor/';;
